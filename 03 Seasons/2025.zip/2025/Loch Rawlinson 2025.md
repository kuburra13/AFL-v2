---
player: Loch Rawlinson
player_link: "[[Loch Rawlinson]]"
team: "[[WCE]]"
Year: 2025
games: 0
af: 0
rating: -2.8
goals: 0
disposals: 0
marks: 0
tackles: 0
clr: 0
kicks: 0
handballs: 0
---
