---
player: Alwyn Davey Jnr
player_link: "[[Alwyn Davey Jnr]]"
team: "[[ESS]]"
Year: 2025
games: 0
af: 0
rating: 43.9
goals: 0
disposals: 0
marks: 0
tackles: 0
clr: 0
kicks: 0
handballs: 0
---
