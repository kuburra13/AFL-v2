---
player: Andy Moniz-Wakefield
player_link: "[[Andy Moniz-Wakefield]]"
team: "[[MELB]]"
Year: 2025
games: 0
af: 42.9
rating: 0
goals: 0
disposals: 0
marks: 0
tackles: 0
clr: 0
kicks: 0
handballs: 0
---
