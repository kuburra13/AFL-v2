---
player: Harry Lemmey
player_link: "[[Harry Lemmey]]"
team: "[[CARL]]"
Year: 2025
games: 0
af: 0
rating: 0.0
goals: 0
disposals: 0
marks: 0
tackles: 0
clr: 0
kicks: 0
handballs: 0
---
